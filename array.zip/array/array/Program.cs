﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace array
{
    class Program
    {
        static void Main(string[] args)
        {
            //One Dimen Array
            string[] cars = { "Volvo", "BMW", "Ford", "Mazda" };
            foreach (string val in cars)
            {
                Console.WriteLine(val);
            }

            //Multi Dimen Array
            string[,] bikes = new string[2,2]
            {
                {"Honda","Hero"},
                {"Suzuki","KTM"}
            };


            foreach (string val1 in bikes)
            {
                Console.WriteLine(val1);
            }

            //Jagged Array
            int[][] arr = new int[2][];

            arr[0] = new int[4] { 11, 21, 56, 78 };
            arr[1] = new int[6] { 42, 61, 37, 41, 59, 63 };

            for (int i = 0; i < arr.Length; i++)
            {
                for (int j = 0; j < arr[i].Length; j++)
                {
                    Console.Write(arr[i][j]+" ");
                }
            }
            Console.Read();
        }
    }
}

      
