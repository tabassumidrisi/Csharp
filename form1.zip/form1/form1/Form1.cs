﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace form1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            resize();
        }
        private void resize()
        {
            button1.Location = new Point(this.Width - button1.Width, 0);
            button2.Location = new Point(this.Width - button2.Width-button2.Width-button3.Width, 0);
            button3.Location = new Point(this.Width - button1.Width-button2.Width, 0);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int a = Convert.ToInt32(MessageBox.Show(" exit ?","app1",MessageBoxButtons.YesNo,MessageBoxIcon.Question));
            if (a == 6)
            {
                Application.Exit();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Maximized)
            {
                this.WindowState = FormWindowState.Normal;
                resize();
            }
            else
            {
                this.WindowState = FormWindowState.Maximized;
                resize();
            }
        }

       }

       
    }

