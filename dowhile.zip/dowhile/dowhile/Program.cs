﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace dowhile
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter value");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, old = 0, nw = 0;
            do
            {
                if(i<=3)
                {
                    Console.Write(i);
                    nw=i;
                    old=i-1;
                }
                else
                {
                    int temp=old*nw;
                    if(temp>n)
                    {
                        break;
                    }
                    Console.Write(temp);
                    old=nw;
                    nw=temp;

                } i++;
            } while (i <= n);
            Console.Read();
        }
    }
}
