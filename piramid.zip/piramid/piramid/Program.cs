﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace piramid
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("enter num");
            int n = Convert.ToInt32(Console.ReadLine());
            int i = 1, k = 1, old = 0, nw = 0, temp = 0;
            int n1 = 0;
            int n2 = n;
            do
            {
                int j = 1;
                do
                {
                    if (k <= 3)
                    {
                        Console.Write(k);
                        nw = k;
                        old = k - 1;
                    }
                    else
                    {
                        temp = old * nw;
                        if (temp > n)
                        {
                            break;
                        }
                        Console.Write(temp);
                        old = nw;
                        nw = temp;
                    }
                    k++;
                    j++;
                }
                while (j <= i);
                if (temp > n)
                {
                    break;
                }
                Console.WriteLine();
                i++;
            }
            while (i <= n);
            Console.Write("\n");
            i=1;
            k=1;
            old=0;
            nw=0;
            temp=0;
            for(i=1;i<n1;i++)
            {
                for(int j=1;j<=i;j++)
                {
                    if(k<=3)
                    {
                        Console.Write(k);
                        nw=k;
                        old=k;
                    }
                    else
                    {
                        temp=old*nw;
                        if(temp>n1)
                        {
                            break;
                        }
                        Console.Write(temp);
                        old=nw;
                        nw=temp;
                    }
                    k++;
                    j++;
                }
                if(temp>n1)
                {
                    break;
                }
                Console.WriteLine();
            }
        }
    }
}

